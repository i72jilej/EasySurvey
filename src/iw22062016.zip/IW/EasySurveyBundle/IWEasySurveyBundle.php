<?php

namespace IW\EasySurveyBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class IWEasySurveyBundle extends Bundle
{
}
